/*
    RemoteCtrl.cpp  

    Implementation of the RemoteCtrl class.

    ---------------------------------------------------------------------------
 
    Copyright (C) 2020, Cornfield Electronics, Inc.
 
    This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 
    Unported License.
 
    To view a copy of this license, visit
    http://creativecommons.org/licenses/by-sa/3.0/
 
    Created by Bill Alessi & Mitch Altman.
 
   ---------------------------------------------------------------------------
*/


#include "System.h"
#include "RemoteCtrl.h"

#ifdef __XTRLCTRL__

RemoteCtrl remote;                  // system remote control mode

/******************************************************************************
 *
 *                               RemoteCtrl 
 *                                                                            
 ******************************************************************************/

/*----------------------------------------------------------------------------*
 *
 *  Name:  RemoteCtrl::charEv
 *
 *  Desc:  Process a character event.
 *
 *  Args:  code             - character to process
 *
 *  Memb:
 *
 *  Note:  When the host uploads a preset to the ArduTouch it will first 
 *         send the '{' character, then send the preset string, then send 
 *         the '$' character (which resets the mode stack and pushes the 
 *         remote mode), then the '}' character.
 *
 *----------------------------------------------------------------------------*/      

bool RemoteCtrl::charEv( char code )    
{
   switch ( code )
   {
      case '=':                     // input pot value and generate event
      {
         // An event of type potEvType will be generated using the input value

         byte value;
         if ( console.getByte( CONSTR("="), &value ) )
         {
            obEvent ev;
            ev.clean();
            ev.setType( potEvType );
            ev.setPotVal( value );
            return synth->evHandler( ev );
         }
      
         break;   
      }

      case '{':                     // begin preset transmission

         synth->segueOff();         // smoothly disable audio
         console.popMode();         // use synth's mode to process preset
         break;

      case '}':                     // end preset transmission

         synth->segueOn();          // smoothly re-enable audio
         break;

      case 'P':                     // set pot event type
      {
         // Pot event types are entered as three consecutive digits:
         //
         //    [ Frame-Left ][ Frame-Right ][ Pot# ]
         //
         // For example: 120 means Frame 12 Pot 0
         //
         // There is no need for an {ENTER} after the 3rd digit is input
         //
         // Note: pot event types are stored internally as 8-bit numbers

         #ifdef CONSOLE_OUTPUT
            _prompt = NULL;         // suppress newln/prompts after each input
         #endif

         char frameL, frameR, pot;

         frameL = console.getDigit( CONSTR("potEvent"), 2 );
         if ( frameL >= 0 ) 
         {
            frameR = console.getDigit( NULL, 2 );
            if ( frameR >= 0 ) 
            {
               pot = console.getDigit( NULL, 1 );
               if ( pot >= 0 )
                  potEvType = POT0 + pot + frameR*2 + frameL*8; 
            }
         }

         #ifdef CONSOLE_OUTPUT
            _prompt = remoteStr;
            console.newprompt();
         #endif

         break;
      }

      case 'Q':                     // handle external request from host 
      {
         byte reqID;

         if ( console.getByte( CONSTR("req#"), &reqID ) )
            Serial.write( synth->xtrlReq( reqID ) );
         break;
      }

      case 'R':                     // reset

         synth->reset();
         break;

      case 'X':                     // handle external command from host
      {
         byte cmdNum;
         byte param;

         if ( console.getByte( CONSTR("cmd#"), &cmdNum ) &&
              console.getByte( CONSTR("param"), &param ) 
              )
            synth->xtrlCmd( cmdNum, param );
         break;
      }

      case 'I':                     // identify synth to host 
      {
         extern const char __PROGNAME__[];              
         const char *str =  __PROGNAME__ ;
         char romChar = pgm_read_byte_near( str++ );
         while ( romChar )
         {
            Serial.write( romChar );
            romChar = pgm_read_byte_near( str++ );
         }

         Serial.write( 0 );
         break;
      }

      #ifdef CONSOLE_OUTPUT

      case '?':
         
         inform();   
         break;

      case chrInfo:

         synth->keybrd.charEv( code );
         console.infoByte( CONSTR("potEvent"), potEvType );
         break;
  
      #endif

      case '!':

         potEvType = 0;

         #ifdef CONSOLE_OUTPUT
            _prompt = remoteStr;      
         #endif

         break;

      default:

         return synth->keybrd.charEv( code );
   }
   return true;
}

/*----------------------------------------------------------------------------*
 *
 *  Name:  RemoteCtrl::evHandler
 *
 *  Desc:  Handle an onboard event.
 *
 *  Args:  ev               - onboard event
 *
 *  Rets:  status           - true if the event was handled
 *
 *----------------------------------------------------------------------------*/      

bool RemoteCtrl::evHandler( obEvent ev )
{
   return synth->keybrd.evHandler(ev);
}

#endif // ifdef __XTRLCTRL__
