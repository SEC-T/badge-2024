/*
    RemoteCtrl.h  

    Declaration of the RemoteCtrl class.

    ---------------------------------------------------------------------------
 
    Copyright (C) 2020, Cornfield Electronics, Inc.
 
    This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 
    Unported License.
 
    To view a copy of this license, visit
    http://creativecommons.org/licenses/by-sa/3.0/
 
    Created by Bill Alessi & Mitch Altman.
 
   ---------------------------------------------------------------------------
*/

#ifndef REMOTECTRL_H_INCLUDED
#define REMOTECTRL_H_INCLUDED

#include "Mode.h"

class RemoteCtrl : public Mode
{
   typedef Mode super;                 // superclass is Mode

   byte potEvType;                     // event type to use with incoming pot values

   #ifdef CONSOLE_OUTPUT
      const char *remoteStr;
      const char *_prompt;
   #endif

   public:

   RemoteCtrl()
   {
      flags &= ~ECHO;
      #ifdef CONSOLE_OUTPUT
         remoteStr = CONSTR("remote");
      #endif
   }

   bool charEv( char );                // process a character event
   bool evHandler( obEvent );          // handle an onboard event

   #ifdef CONSOLE_OUTPUT
      const char* prompt() { return _prompt; }
   #endif
} ;

#ifdef __XTRLCTRL__

   extern RemoteCtrl remote;           // system remote control mode

#endif 

#endif   // ifndef REMOTECTRL_H_INCLUDED
